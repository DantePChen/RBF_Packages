var class_ufe_1_1_version_info =
[
    [ "getBuildDate", "class_ufe_1_1_version_info.html#a75635832f2adf25e0ecc25b173184e15", null ],
    [ "getBuildNumber", "class_ufe_1_1_version_info.html#a7cb2abd0579cb1565210d5dcb895fb1c", null ],
    [ "getGitBranch", "class_ufe_1_1_version_info.html#af29bd34ec3781a65360b6b98a76fef55", null ],
    [ "getGitCommit", "class_ufe_1_1_version_info.html#a3f90b49f252b08e5d130f8092ef0bf5b", null ],
    [ "getMajorVersion", "class_ufe_1_1_version_info.html#a46e634f29053bc54710c2b1b7687c086", null ],
    [ "getMinorVersion", "class_ufe_1_1_version_info.html#ae5b6882966a1c77b4aca10bc727c7b67", null ],
    [ "getPatchLevel", "class_ufe_1_1_version_info.html#a5057b5525efb70cf2650a1ccf5214882", null ]
];