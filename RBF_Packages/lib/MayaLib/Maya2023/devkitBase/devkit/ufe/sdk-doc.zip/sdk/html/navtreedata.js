/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "ufe", "index.html", [
    [ "UFE API Documentation", "index.html", null ],
    [ "UFE Concepts and Architecture", "ufe_philosophy.html", [
      [ "Fundamental Concepts", "ufe_philosophy.html#fundamentals", null ],
      [ "Architecture", "ufe_philosophy.html#architecture", null ],
      [ "Implementation", "ufe_philosophy.html#implementation", null ],
      [ "Runtime Interfaces", "ufe_philosophy.html#runTimeInterfaces", null ],
      [ "Notifications", "ufe_philosophy.html#notifications", null ],
      [ "Selection", "ufe_philosophy.html#selection", null ],
      [ "Global Selection", "ufe_philosophy.html#globalSelection", null ],
      [ "Undo / Redo", "ufe_philosophy.html#undoRedo", null ],
      [ "Path Strings", "ufe_philosophy.html#pathString", null ],
      [ "Versioning", "ufe_philosophy.html#versioning", null ]
    ] ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_cfg_compiler_macros_8h.html",
"class_ufe_1_1_camera_changed.html#a924afe735575aef40c13a81fa1e98705",
"class_ufe_1_1_object3d_handler.html#ae95a03de7692beec3f885c9ed3f874fa",
"class_ufe_1_1_scene.html#a0daeed44082ac89c65b5d20fdd1b1eb6",
"class_ufe_1_1_subject.html#a209a853dde2b0da1f2cf91e69155edfb",
"functions_func.html",
"struct_ufe_1_1_run_time_mgr_1_1_handlers.html#a0020366ebe5fc7c78b5d961c236a4981"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';