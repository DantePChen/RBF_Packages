var class_peptide_1_1_version_info =
[
    [ "FileFormatVersionNumbers", "class_peptide_1_1_version_info.html#a8acf7f43b24e3b390f543a718d96918a", [
      [ "kInitial", "class_peptide_1_1_version_info.html#a8acf7f43b24e3b390f543a718d96918aa8288d748256799a5aab9847a6c354ce7", null ],
      [ "kCurrent", "class_peptide_1_1_version_info.html#a8acf7f43b24e3b390f543a718d96918aaa1f14acc9c84a430477914441ad13a97", null ]
    ] ],
    [ "VersionInfo", "class_peptide_1_1_version_info.html#afc52d3e6344b3152172091e52319adf7", null ],
    [ "getFileFormatVersionID", "class_peptide_1_1_version_info.html#a3bea140e1a9ec9ff41a12e44cf65f3db", null ],
    [ "getLibSuffix", "class_peptide_1_1_version_info.html#a2b29bcc80d21711702f45d58af5b336b", null ],
    [ "getMajorVersion", "class_peptide_1_1_version_info.html#a29763cee55776a8c1bff6d83493b2798", null ],
    [ "getMinorVersion", "class_peptide_1_1_version_info.html#aa44de03ff1bfe05fab70c3dfcc29dfdd", null ],
    [ "getPatchLevel", "class_peptide_1_1_version_info.html#a3387d56fc66e5c80f902a8c27c139e4d", null ],
    [ "getVersionID", "class_peptide_1_1_version_info.html#a327217ed6bfbba59b3af3513b9341fd4", null ],
    [ "getVersionInfo", "class_peptide_1_1_version_info.html#afb5fef7a7c74cef80253f08c31f6620f", null ]
];