var class_ufe_1_1_attribute_filename =
[
    [ "Ptr", "class_ufe_1_1_attribute_filename.html#a301c98f38fcdecd1eb1e30327357339b", null ],
    [ "Attribute", "class_ufe_1_1_attribute_filename.html#a9401eb6e03cf4b3c8f15df1d672efe3b", null ],
    [ "Attribute", "class_ufe_1_1_attribute_filename.html#ab625a50e549e94e40a7f87fd8c2679f4", null ],
    [ "Attribute", "class_ufe_1_1_attribute_filename.html#afbe1bd9d159ca93421363f60b7089311", null ],
    [ "get", "class_ufe_1_1_attribute_filename.html#a622131b35e98ca322b2ab22087075641", null ],
    [ "set", "class_ufe_1_1_attribute_filename.html#a7aa4794b18b7e1a84840ea71ce3d8d42", null ],
    [ "setCmd", "class_ufe_1_1_attribute_filename.html#ab54858e6842eb0b1b8804d8ffe489c67", null ],
    [ "type", "class_ufe_1_1_attribute_filename.html#a431d54a24492180fda3381986c6ca3f8", null ]
];