var class_ufe_1_1_light_1_1_sphere_interface =
[
    [ "~SphereInterface", "class_ufe_1_1_light_1_1_sphere_interface.html#ac97354f93ab09d0279ee2cca58af9ab2", null ],
    [ "sphereProps", "class_ufe_1_1_light_1_1_sphere_interface.html#a1605f2a2855b1df04ea9412e10ab69ea", null ],
    [ "sphereProps", "class_ufe_1_1_light_1_1_sphere_interface.html#addbea913cc8c2e3001ce275105b6b5f1", null ],
    [ "spherePropsCmd", "class_ufe_1_1_light_1_1_sphere_interface.html#a515a555d46a6f737cabff9e60831c77f", null ]
];