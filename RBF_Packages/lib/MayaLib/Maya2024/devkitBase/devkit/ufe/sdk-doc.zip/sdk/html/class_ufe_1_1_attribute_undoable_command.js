var class_ufe_1_1_attribute_undoable_command =
[
    [ "Ptr", "class_ufe_1_1_attribute_undoable_command.html#abe9b6c7aa8dbf9746954fd0897de477e", null ],
    [ "AttributeUndoableCommand", "class_ufe_1_1_attribute_undoable_command.html#a680cb51fdcd9fe213c8eaf4bd7c96730", null ],
    [ "~AttributeUndoableCommand", "class_ufe_1_1_attribute_undoable_command.html#ab9ea502f1fcc6a5329ddee2bd03852ee", null ],
    [ "attribute", "class_ufe_1_1_attribute_undoable_command.html#acb80106cff3b8634fc1dc79fe8d1809e", null ]
];