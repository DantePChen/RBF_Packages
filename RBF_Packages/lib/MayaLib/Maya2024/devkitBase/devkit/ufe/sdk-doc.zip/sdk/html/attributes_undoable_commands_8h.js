var attributes_undoable_commands_8h =
[
    [ "AddAttributeUndoableCommand", "attributes_undoable_commands_8h.html#aff45aef3139a83c812b3315cb331138f", null ],
    [ "RenameAttributeUndoableCommand", "attributes_undoable_commands_8h.html#a81d08b3dfc3581d22510152e28251bb5", null ]
];