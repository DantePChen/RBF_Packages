var class_ufe_1_1_connections =
[
    [ "Ptr", "class_ufe_1_1_connections.html#a1152c3117262a5082d1ded668f2f0e20", null ],
    [ "AttributeType", "class_ufe_1_1_connections.html#a8c8f985d2dded22ae23dd36230505ee4", [
      [ "ATTR_IS_SOURCE", "class_ufe_1_1_connections.html#a8c8f985d2dded22ae23dd36230505ee4a157aadae7a06e8915cded4abf40dd539", null ],
      [ "ATTR_IS_DESTINATION", "class_ufe_1_1_connections.html#a8c8f985d2dded22ae23dd36230505ee4a9d9a29546deb2f74d9c758a82ecb1da9", null ],
      [ "ATTR_ANY", "class_ufe_1_1_connections.html#a8c8f985d2dded22ae23dd36230505ee4aa2effcaed016deda61b788def39122bb", null ]
    ] ],
    [ "Connections", "class_ufe_1_1_connections.html#afd99a8c33c9316f11a874794c841b1b1", null ],
    [ "~Connections", "class_ufe_1_1_connections.html#a21ce93a3ade0b3cd0167411485dbcd82", null ],
    [ "Connections", "class_ufe_1_1_connections.html#af6c431fcbe39a6b228ea0454b48ed1b7", null ],
    [ "Connections", "class_ufe_1_1_connections.html#a4524125071cffd9955af533a6a2c3aa0", null ],
    [ "allConnections", "class_ufe_1_1_connections.html#a51202847f27cb21050f6227c976cb16e", null ],
    [ "connections", "class_ufe_1_1_connections.html#afcffe7af1fbc60961070c6ea2ad7d20e", null ],
    [ "hasConnection", "class_ufe_1_1_connections.html#a682c2c786c7c14aacd85ab283d2a5e08", null ],
    [ "operator=", "class_ufe_1_1_connections.html#a46e6f0062e8db322904a4fa3b45cd135", null ],
    [ "operator=", "class_ufe_1_1_connections.html#a49e42a256a1b6ef749af1c62cf97e6c0", null ]
];