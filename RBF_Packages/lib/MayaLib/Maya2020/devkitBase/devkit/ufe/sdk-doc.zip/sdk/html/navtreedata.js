var NAVTREE =
[
  [ "ufe", "index.html", [
    [ "UFE API Documentation", "index.html", null ],
    [ "UFE Concepts and Architecture", "ufe_philosophy.html", [
      [ "Fundamental Concepts", "ufe_philosophy.html#fundamentals", null ],
      [ "Architecture", "ufe_philosophy.html#architecture", null ],
      [ "Implementation", "ufe_philosophy.html#implementation", null ],
      [ "Run Time Interfaces", "ufe_philosophy.html#runTimeInterfaces", null ],
      [ "Notifications", "ufe_philosophy.html#notifications", null ],
      [ "Selection", "ufe_philosophy.html#selection", null ],
      [ "Global Selection", "ufe_philosophy.html#globalSelection", null ],
      [ "Undo / Redo", "ufe_philosophy.html#undoRedo", null ],
      [ "Versioning", "ufe_philosophy.html#versioning", null ]
    ] ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_cfg_compiler_macros_8h.html",
"class_ufe_1_1_path_segment.html#aff6a7cb69f9bebed70c00a318adcf8d4",
"class_ufe_1_1_translate_undoable_command.html#a04c0f902252b6d574aa810ba9837e836"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';