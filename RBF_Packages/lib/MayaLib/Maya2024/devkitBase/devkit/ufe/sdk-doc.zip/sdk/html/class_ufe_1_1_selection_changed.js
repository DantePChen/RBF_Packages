var class_ufe_1_1_selection_changed =
[
    [ "OpType", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070", [
      [ "Append", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070a42ea617363804854319d28e799a8b7bc", null ],
      [ "Remove", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070ab7182bf78eb1db6c1644be617dc749ff", null ],
      [ "Insert", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070a001ae432f883cfa7631b9435abd95945", null ],
      [ "Clear", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070ae4c695615dc4c377e19e832d980176ab", null ],
      [ "ReplaceWith", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070ac012941f090dd46f4331dc9c50439e03", null ],
      [ "SelectionCompositeNotification", "class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070a0fa321862501438eabf34a45f76a3836", null ]
    ] ],
    [ "SelectionChanged", "class_ufe_1_1_selection_changed.html#adb9e72ea1f8331e874596303f019ef0f", null ],
    [ "SelectionChanged", "class_ufe_1_1_selection_changed.html#a7507c015c28456b9df93ff799b3fc074", null ],
    [ "~SelectionChanged", "class_ufe_1_1_selection_changed.html#a553e2cd91a704c7ea01c990ed038f5d0", null ],
    [ "opType", "class_ufe_1_1_selection_changed.html#a52bfc7f4c672999d6ed7e83d439f464f", null ],
    [ "fOpType", "class_ufe_1_1_selection_changed.html#a396cff90fe32140f30f187ab0ab91e2d", null ]
];