var class_ufe_1_1_selection_append_item =
[
    [ "SelectionAppendItem", "class_ufe_1_1_selection_append_item.html#ab93757a0e81610c82d607acad566b337", null ],
    [ "createAndExecute", "class_ufe_1_1_selection_append_item.html#ac753ad14769b1c6653a9a88b40be8a4c", null ],
    [ "redo", "class_ufe_1_1_selection_append_item.html#a11230c66c91975b646256267e43a9b23", null ],
    [ "undo", "class_ufe_1_1_selection_append_item.html#a42363b3e62084dca52b5a5ff8f76070a", null ],
    [ "fPath", "class_ufe_1_1_selection_append_item.html#abda7b16f9e32e88d3bf50435423bde5d", null ],
    [ "fSn", "class_ufe_1_1_selection_append_item.html#aad17c937f49fea4e4de58e62fd817339", null ]
];