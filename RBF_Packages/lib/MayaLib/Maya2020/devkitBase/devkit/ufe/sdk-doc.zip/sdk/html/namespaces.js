var namespaces =
[
    [ "GlobalSelection", "namespace_global_selection.html", null ],
    [ "std", "namespacestd.html", null ],
    [ "Ufe", "namespace_ufe.html", "namespace_ufe" ],
    [ "Ufe_v1", "namespace_ufe__v1.html", null ]
];