var class_ufe_1_1_attribute_def =
[
    [ "ConstPtr", "class_ufe_1_1_attribute_def.html#a727ff5f15070e17188cbaf4319a4a76e", null ],
    [ "IOType", "class_ufe_1_1_attribute_def.html#ac8d29ed599792cc805bf5914229664c8", [
      [ "INPUT_ATTR", "class_ufe_1_1_attribute_def.html#ac8d29ed599792cc805bf5914229664c8abf3691ae81efb5921962c607e8bddf65", null ],
      [ "OUTPUT_ATTR", "class_ufe_1_1_attribute_def.html#ac8d29ed599792cc805bf5914229664c8a273cd43607851361c3bddc64e039c705", null ]
    ] ],
    [ "~AttributeDef", "class_ufe_1_1_attribute_def.html#afffd7d057ea899c42d8d28843d5626ae", null ],
    [ "defaultValue", "class_ufe_1_1_attribute_def.html#afe597ca8028b2f06e65078063d298b5d", null ],
    [ "getMetadata", "class_ufe_1_1_attribute_def.html#aa343a75e5e2240fcf697d3146f412928", null ],
    [ "hasMetadata", "class_ufe_1_1_attribute_def.html#af4f92f2d69e68050e1b13192e68dc1cd", null ],
    [ "ioType", "class_ufe_1_1_attribute_def.html#af08d084589a6735bc0ebf215c6a58263", null ],
    [ "name", "class_ufe_1_1_attribute_def.html#ac05b83d78ae8d15ab741b121c7d007fd", null ],
    [ "type", "class_ufe_1_1_attribute_def.html#aa09a262b9b54b87337ac75495bc1f38a", null ]
];