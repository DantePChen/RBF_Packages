var struct_ufe_1_1_duplicate =
[
    [ "Duplicate", "struct_ufe_1_1_duplicate.html#af84c371d2155769494d625ac74bc86b0", null ],
    [ "Duplicate", "struct_ufe_1_1_duplicate.html#a16e22881d92adea6ddedfea0a3e5a7a7", null ],
    [ "item", "struct_ufe_1_1_duplicate.html#abc4701680d247bd02b7c8e59629ef140", null ],
    [ "undoableCommand", "struct_ufe_1_1_duplicate.html#aea1e8cabb065ee6332e445072628c06e", null ]
];