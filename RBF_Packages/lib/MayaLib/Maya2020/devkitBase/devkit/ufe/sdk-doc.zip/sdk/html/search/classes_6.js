var searchData=
[
  ['notification',['Notification',['../class_ufe_1_1_notification.html',1,'Ufe']]],
  ['notificationguard',['NotificationGuard',['../class_ufe_1_1_notification_guard.html',1,'Ufe']]]
];
