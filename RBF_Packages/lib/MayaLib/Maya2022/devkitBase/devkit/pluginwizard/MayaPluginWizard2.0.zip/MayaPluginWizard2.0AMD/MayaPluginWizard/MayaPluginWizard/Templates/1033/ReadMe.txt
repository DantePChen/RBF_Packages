========================================================================
    MayaPlugInWizard : "[!output PROJECT_NAME]" Project Overview
========================================================================

MayaPlugInWizard has created this "[!output PROJECT_NAME]" project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.

MayaPlugInWizard.vcproj
    This is the main project file for projects generated using an Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Options.txt
	This text file explains which options you selected for your new project.

/////////////////////////////////////////////////////////////////////////////
Other notes:

/////////////////////////////////////////////////////////////////////////////
