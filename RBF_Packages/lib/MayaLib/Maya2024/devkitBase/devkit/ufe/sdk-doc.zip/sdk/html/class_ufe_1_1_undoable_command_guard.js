var class_ufe_1_1_undoable_command_guard =
[
    [ "UndoableCommandGuard", "class_ufe_1_1_undoable_command_guard.html#a12ebf97712eb2e977e80e8613652e4ed", null ],
    [ "UndoableCommandGuard", "class_ufe_1_1_undoable_command_guard.html#ab46567d2c38702632c2c7505cb7d0065", null ],
    [ "~UndoableCommandGuard", "class_ufe_1_1_undoable_command_guard.html#a64d7bb2fdcd14da0e3db3d1778cfdb7f", null ],
    [ "operator=", "class_ufe_1_1_undoable_command_guard.html#a2ef1e874d85e82fc610b0a11f8c1d603", null ],
    [ "setSuccess", "class_ufe_1_1_undoable_command_guard.html#a43bad89d1e3b0bf8c44ab1e0aae6f447", null ],
    [ "fPreviousCommandMgr", "class_ufe_1_1_undoable_command_guard.html#aedd9e4f4bd6fcc782b4e6f4aa6bf2afe", null ]
];