var dir_11fbc4217d50ab21044e5ad6614aede5 =
[
    [ "peptide", "dir_25a97eba3131a7ca8e8a0122dc272892.html", "dir_25a97eba3131a7ca8e8a0122dc272892" ],
    [ "ufe", "dir_e22cea68f6bc9fd1669e4ee9a744da32.html", "dir_e22cea68f6bc9fd1669e4ee9a744da32" ]
];