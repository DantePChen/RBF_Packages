var searchData=
[
  ['globalselection',['GlobalSelection',['../namespace_global_selection.html',1,'']]]
];
