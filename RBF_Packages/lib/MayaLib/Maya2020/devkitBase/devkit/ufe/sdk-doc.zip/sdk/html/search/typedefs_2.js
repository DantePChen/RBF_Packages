var searchData=
[
  ['observers',['Observers',['../class_ufe_1_1_subject.html#ac1782eedd9615a2e4344dca83b734017',1,'Ufe::Subject']]],
  ['ops',['Ops',['../class_ufe_1_1_selection_composite_notification.html#ac6f7259751353ea72cf0f02021f2a401',1,'Ufe::SelectionCompositeNotification']]]
];
