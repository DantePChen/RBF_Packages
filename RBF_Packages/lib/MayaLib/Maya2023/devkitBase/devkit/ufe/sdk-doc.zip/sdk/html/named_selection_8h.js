var named_selection_8h =
[
    [ "Ptr", "named_selection_8h.html#a2db5f890f80efea872e3f9429ac8b52f", null ],
    [ "get", "named_selection_8h.html#af03a27c61db027c660ec40b96d6b8490", null ],
    [ "remove", "named_selection_8h.html#a5a8c89a076db14be654d6881a008ca81", null ]
];