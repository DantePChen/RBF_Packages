var class_ufe_1_1_connection =
[
    [ "Ptr", "class_ufe_1_1_connection.html#a818b29af8b40cc093ccdd74bb4242465", null ],
    [ "Connection", "class_ufe_1_1_connection.html#ac9bf63b938e4fa8692d2ba5578f5137e", null ],
    [ "~Connection", "class_ufe_1_1_connection.html#a40bade746c630275636815a31effb2e7", null ],
    [ "Connection", "class_ufe_1_1_connection.html#a9f7855086bc253034284c0726451ba28", null ],
    [ "Connection", "class_ufe_1_1_connection.html#ae712208166f57073ef09932ad08b8b48", null ],
    [ "dst", "class_ufe_1_1_connection.html#a32503d6d5c7f92e0327f36179caf3a0e", null ],
    [ "operator=", "class_ufe_1_1_connection.html#aa9989a1cbeeb338efb7d5d4f8e83715d", null ],
    [ "operator=", "class_ufe_1_1_connection.html#acee476311474d7f01cd9615bcf089b53", null ],
    [ "src", "class_ufe_1_1_connection.html#a174fa7c1220788a91645a8a49a48c042", null ],
    [ "fDst", "class_ufe_1_1_connection.html#ade646c698ea19e6f3b4b8780bb32f403", null ],
    [ "fSrc", "class_ufe_1_1_connection.html#a6046e4964d09ddc2899971563b1b7a88", null ]
];