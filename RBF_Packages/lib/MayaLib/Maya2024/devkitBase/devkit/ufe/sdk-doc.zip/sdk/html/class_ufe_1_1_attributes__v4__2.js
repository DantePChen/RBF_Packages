var class_ufe_1_1_attributes__v4__2 =
[
    [ "Enums", "class_ufe_1_1_attributes__v4__2.html#aae3d2876ce37562be143045ed8259cb4", null ],
    [ "Ptr", "class_ufe_1_1_attributes__v4__2.html#a191b70e7863f090e1dd4b7346db560c6", null ],
    [ "~Attributes_v4_2", "class_ufe_1_1_attributes__v4__2.html#a4a4b2ddaebce4a61dfee470f9fb5bb27", null ],
    [ "getEnums", "class_ufe_1_1_attributes__v4__2.html#a21b258f1dce702c7242376f7df8158b1", null ]
];