var searchData=
[
  ['globalselection_2eh',['globalSelection.h',['../global_selection_8h.html',1,'']]]
];
