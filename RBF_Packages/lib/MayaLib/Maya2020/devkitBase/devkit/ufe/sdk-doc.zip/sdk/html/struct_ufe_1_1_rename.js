var struct_ufe_1_1_rename =
[
    [ "Rename", "struct_ufe_1_1_rename.html#a869a080f8800ba1d4af414edfd761a5b", null ],
    [ "Rename", "struct_ufe_1_1_rename.html#a16338f8e44ec4860e0334f2a497fa407", null ],
    [ "item", "struct_ufe_1_1_rename.html#aa2dc3e1ff7a55d27b82ce5acc3d4a5cd", null ],
    [ "undoableCommand", "struct_ufe_1_1_rename.html#aec8b9df0fc472496700c9e497bffbfe1", null ]
];