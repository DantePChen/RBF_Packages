var class_ufe_1_1_context_ops_handler =
[
    [ "Ptr", "class_ufe_1_1_context_ops_handler.html#acf5ee180cec41e59caa1348243f1fc38", null ],
    [ "ContextOpsHandler", "class_ufe_1_1_context_ops_handler.html#a93fcbd50d78baf2c18ae27905f26234b", null ],
    [ "ContextOpsHandler", "class_ufe_1_1_context_ops_handler.html#a98c83e16eb6365546365ce56e8e64079", null ],
    [ "~ContextOpsHandler", "class_ufe_1_1_context_ops_handler.html#aae8d3ef785eb182488e0137454bbdf37", null ],
    [ "contextOps", "class_ufe_1_1_context_ops_handler.html#a77771f337b1143c3f3d703254f70d21e", null ]
];