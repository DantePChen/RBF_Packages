var class_ufe_1_1_connection_result_undoable_command =
[
    [ "Ptr", "class_ufe_1_1_connection_result_undoable_command.html#a9b703493c609deb4cea73fb85181c64c", null ],
    [ "ConnectionResultUndoableCommand", "class_ufe_1_1_connection_result_undoable_command.html#ad9facc3ff3b3831049c59e59398583b7", null ],
    [ "~ConnectionResultUndoableCommand", "class_ufe_1_1_connection_result_undoable_command.html#a47e6b2233b9b243246e449e31ffd50d3", null ],
    [ "connection", "class_ufe_1_1_connection_result_undoable_command.html#a55ec5d6bbbc7c4eb7d96a91f6cc2ecf2", null ]
];