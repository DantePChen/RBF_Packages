var dir_25a97eba3131a7ca8e8a0122dc272892 =
[
    [ "config", "dir_b9bb2c27422ff907faa82a47619ab897.html", "dir_b9bb2c27422ff907faa82a47619ab897" ],
    [ "versioning", "dir_4218f2ee3809d20f33519bd0071d6dbe.html", "dir_4218f2ee3809d20f33519bd0071d6dbe" ]
];