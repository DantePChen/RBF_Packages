var searchData=
[
  ['baseclass',['BaseClass',['../class_ufe_1_1_observable_selection.html#a3f55362018cdaf1f6eae330e3d7d31b8',1,'Ufe::ObservableSelection']]]
];
