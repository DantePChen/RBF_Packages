var class_ufe_1_1_material =
[
    [ "Ptr", "class_ufe_1_1_material.html#aec73483e34afb818af915453007bcf7d", null ],
    [ "Material", "class_ufe_1_1_material.html#a20972fd46005b6452b2c47a232f23666", null ],
    [ "Material", "class_ufe_1_1_material.html#af9bafe00db528528887d6dc98690f5a6", null ],
    [ "~Material", "class_ufe_1_1_material.html#a2fa0f513c352fecee6522962ba57b454", null ],
    [ "getMaterials", "class_ufe_1_1_material.html#af619e52a106bfc189d5d298e2b313295", null ],
    [ "material", "class_ufe_1_1_material.html#a4acd8bec7c30d40439ec2caf8e3609c5", null ]
];