var searchData=
[
  ['undoablecommand',['undoableCommand',['../struct_ufe_1_1_duplicate.html#aea1e8cabb065ee6332e445072628c06e',1,'Ufe::Duplicate::undoableCommand()'],['../struct_ufe_1_1_rename.html#aec8b9df0fc472496700c9e497bffbfe1',1,'Ufe::Rename::undoableCommand()']]]
];
