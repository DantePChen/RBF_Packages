var struct_ufe_1_1_selection_composite_notification_1_1_op =
[
    [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#ad2e99965dfa7487b2da9029222ddc55c", null ],
    [ "item", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#a2321b2b3ad6e94d18ad2fc2e40223b49", null ],
    [ "opType", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#af1a4a4f0e3597e243216034a6b2b4939", null ]
];