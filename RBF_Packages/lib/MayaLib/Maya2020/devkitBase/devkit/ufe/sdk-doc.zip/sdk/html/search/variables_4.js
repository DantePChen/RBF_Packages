var searchData=
[
  ['optype',['opType',['../struct_ufe_1_1_selection_composite_notification_1_1_op.html#af1a4a4f0e3597e243216034a6b2b4939',1,'Ufe::SelectionCompositeNotification::Op']]]
];
