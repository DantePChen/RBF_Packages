var class_ufe_1_1_translate_undoable_command =
[
    [ "Ptr", "class_ufe_1_1_translate_undoable_command.html#a04c0f902252b6d574aa810ba9837e836", null ],
    [ "TranslateUndoableCommand", "class_ufe_1_1_translate_undoable_command.html#a0c5a88ea34101bfdbfddd9ed7b10e8ec", null ],
    [ "TranslateUndoableCommand", "class_ufe_1_1_translate_undoable_command.html#a37ac000a288094c7f71d291e3e19ae8d", null ],
    [ "~TranslateUndoableCommand", "class_ufe_1_1_translate_undoable_command.html#a1d14ee801272cbf6c3cde8b3c2245da2", null ],
    [ "translate", "class_ufe_1_1_translate_undoable_command.html#ab4f52bd61e11664b5476eafd5d198061", null ]
];