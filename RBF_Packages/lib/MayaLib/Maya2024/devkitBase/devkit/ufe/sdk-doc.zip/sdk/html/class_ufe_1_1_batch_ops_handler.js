var class_ufe_1_1_batch_ops_handler =
[
    [ "Ptr", "class_ufe_1_1_batch_ops_handler.html#a94944dd02d49472ce624a3bee7862bc8", null ],
    [ "BatchOpsHandler", "class_ufe_1_1_batch_ops_handler.html#a691cc76add5653f671a1868cc2d435e5", null ],
    [ "BatchOpsHandler", "class_ufe_1_1_batch_ops_handler.html#a1329bb303a2b951829de43a782d861c4", null ],
    [ "~BatchOpsHandler", "class_ufe_1_1_batch_ops_handler.html#a5dee6ccfa04d43181cf5d23fad754fb3", null ],
    [ "duplicateSelectionCmd", "class_ufe_1_1_batch_ops_handler.html#aa285419ad8bdcc831e30ba1f5de6d9ed", null ],
    [ "duplicateSelectionCmd_", "class_ufe_1_1_batch_ops_handler.html#a48f75948af0da84b7e4ca10db1b9dc2c", null ]
];