var searchData=
[
  ['undo',['undo',['../class_ufe_1_1_selection_append_item.html#a42363b3e62084dca52b5a5ff8f76070a',1,'Ufe::SelectionAppendItem::undo()'],['../class_ufe_1_1_selection_remove_item.html#a20593ae9431da0c9fcec9e3e433aa37a',1,'Ufe::SelectionRemoveItem::undo()'],['../class_ufe_1_1_undoable_command.html#a0e3b24f3fde46c77a2138972c45cc7b8',1,'Ufe::UndoableCommand::undo()'],['../class_ufe_1_1_composite_undoable_command.html#a479c80d78337330f5f84f5544f06d2d0',1,'Ufe::CompositeUndoableCommand::undo()']]],
  ['undoablecommand',['UndoableCommand',['../class_ufe_1_1_undoable_command.html#a3bf3116cd35255b747e8930709277264',1,'Ufe::UndoableCommand::UndoableCommand()'],['../class_ufe_1_1_undoable_command.html#ac6eebde4c2d4df0fad0dbb662b978eae',1,'Ufe::UndoableCommand::UndoableCommand(const UndoableCommand &amp;)=delete']]],
  ['unregister',['unregister',['../class_ufe_1_1_run_time_mgr.html#a5813a7c407e7824f0a96ba82713340f0',1,'Ufe::RunTimeMgr']]]
];
