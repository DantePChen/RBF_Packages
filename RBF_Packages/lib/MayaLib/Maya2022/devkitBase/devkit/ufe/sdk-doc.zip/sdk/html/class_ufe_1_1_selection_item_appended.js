var class_ufe_1_1_selection_item_appended =
[
    [ "SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html#aa46e08aac5724c04450a9e63d12e0df3", null ],
    [ "SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html#ab97abec3f1f0440a381297c24aac0bc9", null ],
    [ "~SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html#a24c5408e245b85a6c3708453cbcaf6f0", null ],
    [ "item", "class_ufe_1_1_selection_item_appended.html#a79998eeb0e78508b344928fc241ce0d9", null ],
    [ "fItem", "class_ufe_1_1_selection_item_appended.html#a0aafc5ed2f025b7ab594f763c27d6a18", null ]
];