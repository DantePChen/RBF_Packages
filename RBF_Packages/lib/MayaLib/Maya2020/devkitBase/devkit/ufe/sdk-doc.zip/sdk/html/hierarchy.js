var hierarchy =
[
    [ "Ufe::AppendedChild", "struct_ufe_1_1_appended_child.html", null ],
    [ "Ufe::Duplicate", "struct_ufe_1_1_duplicate.html", null ],
    [ "std::hash< Ufe::PathComponent >", "structstd_1_1hash_3_01_ufe_1_1_path_component_01_4.html", null ],
    [ "std::hash< Ufe_v1 ::Path >", "structstd_1_1hash_3_01_ufe__v1_01_1_1_path_01_4.html", null ],
    [ "Ufe::Hierarchy", "class_ufe_1_1_hierarchy.html", null ],
    [ "Ufe::HierarchyHandler", "class_ufe_1_1_hierarchy_handler.html", null ],
    [ "Ufe::Matrix4d", "struct_ufe_1_1_matrix4d.html", null ],
    [ "Ufe::Notification", "class_ufe_1_1_notification.html", [
      [ "Ufe::ObjectAdd", "class_ufe_1_1_object_add.html", null ],
      [ "Ufe::ObjectDelete", "class_ufe_1_1_object_delete.html", [
        [ "Ufe::ObjectPostDelete", "class_ufe_1_1_object_post_delete.html", null ],
        [ "Ufe::ObjectPreDelete", "class_ufe_1_1_object_pre_delete.html", null ]
      ] ],
      [ "Ufe::ObjectPathChange", "class_ufe_1_1_object_path_change.html", [
        [ "Ufe::ObjectPathAdd", "class_ufe_1_1_object_path_add.html", null ],
        [ "Ufe::ObjectPathRemove", "class_ufe_1_1_object_path_remove.html", null ],
        [ "Ufe::ObjectRename", "class_ufe_1_1_object_rename.html", null ],
        [ "Ufe::ObjectReparent", "class_ufe_1_1_object_reparent.html", null ]
      ] ],
      [ "Ufe::SelectionChanged", "class_ufe_1_1_selection_changed.html", [
        [ "Ufe::SelectionCleared", "class_ufe_1_1_selection_cleared.html", null ],
        [ "Ufe::SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html", null ],
        [ "Ufe::SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html", null ],
        [ "Ufe::SelectionItemRemoved", "class_ufe_1_1_selection_item_removed.html", null ],
        [ "Ufe::SelectionReplaced", "class_ufe_1_1_selection_replaced.html", null ]
      ] ],
      [ "Ufe::Transform3dChanged", "class_ufe_1_1_transform3d_changed.html", null ]
    ] ],
    [ "Ufe::NotificationGuard", "class_ufe_1_1_notification_guard.html", null ],
    [ "Ufe::Observer", "class_ufe_1_1_observer.html", null ],
    [ "Ufe::SelectionCompositeNotification::Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html", null ],
    [ "Ufe::Path", "class_ufe_1_1_path.html", null ],
    [ "Ufe::PathComponent", "class_ufe_1_1_path_component.html", null ],
    [ "Ufe::PathSegment", "class_ufe_1_1_path_segment.html", null ],
    [ "Ufe::Rename", "struct_ufe_1_1_rename.html", null ],
    [ "Ufe::RunTimeMgr", "class_ufe_1_1_run_time_mgr.html", null ],
    [ "Ufe::Scene", "class_ufe_1_1_scene.html", null ],
    [ "Ufe::SceneItem", "class_ufe_1_1_scene_item.html", null ],
    [ "Ufe::SceneItemOps", "class_ufe_1_1_scene_item_ops.html", null ],
    [ "Ufe::SceneItemOpsHandler", "class_ufe_1_1_scene_item_ops_handler.html", null ],
    [ "Ufe::Selection", "class_ufe_1_1_selection.html", [
      [ "Ufe::ObservableSelection", "class_ufe_1_1_observable_selection.html", null ]
    ] ],
    [ "Ufe::Subject", "class_ufe_1_1_subject.html", [
      [ "Ufe::ObservableSelection", "class_ufe_1_1_observable_selection.html", null ]
    ] ],
    [ "Ufe::Transform3d", "class_ufe_1_1_transform3d.html", null ],
    [ "Ufe::Transform3dHandler", "class_ufe_1_1_transform3d_handler.html", null ],
    [ "Ufe::UndoableCommand", "class_ufe_1_1_undoable_command.html", [
      [ "Ufe::BaseTransformUndoableCommand", "class_ufe_1_1_base_transform_undoable_command.html", [
        [ "Ufe::RotateUndoableCommand", "class_ufe_1_1_rotate_undoable_command.html", null ],
        [ "Ufe::ScaleUndoableCommand", "class_ufe_1_1_scale_undoable_command.html", null ],
        [ "Ufe::TranslateUndoableCommand", "class_ufe_1_1_translate_undoable_command.html", null ]
      ] ],
      [ "Ufe::CompositeUndoableCommand", "class_ufe_1_1_composite_undoable_command.html", null ],
      [ "Ufe::SelectionAppendItem", "class_ufe_1_1_selection_append_item.html", null ],
      [ "Ufe::SelectionRemoveItem", "class_ufe_1_1_selection_remove_item.html", null ]
    ] ],
    [ "Ufe::Vector3d", "struct_ufe_1_1_vector3d.html", null ],
    [ "Ufe::VersionInfo", "class_ufe_1_1_version_info.html", null ]
];