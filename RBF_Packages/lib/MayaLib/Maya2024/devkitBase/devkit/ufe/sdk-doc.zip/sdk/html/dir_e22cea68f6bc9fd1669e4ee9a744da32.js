var dir_e22cea68f6bc9fd1669e4ee9a744da32 =
[
    [ "common", "dir_4ec70c25e987b341db5583b22f83e88c.html", "dir_4ec70c25e987b341db5583b22f83e88c" ],
    [ "attribute.h", "attribute_8h.html", "attribute_8h" ],
    [ "attributeDef.h", "attribute_def_8h.html", [
      [ "AttributeDef", "class_ufe_1_1_attribute_def.html", "class_ufe_1_1_attribute_def" ]
    ] ],
    [ "attributeInfo.h", "attribute_info_8h.html", [
      [ "AttributeInfo", "class_ufe_1_1_attribute_info.html", "class_ufe_1_1_attribute_info" ]
    ] ],
    [ "attributes.h", "attributes_8h.html", [
      [ "Attributes", "class_ufe_1_1_attributes.html", "class_ufe_1_1_attributes" ],
      [ "Attributes_v4_2", "class_ufe_1_1_attributes__v4__2.html", "class_ufe_1_1_attributes__v4__2" ]
    ] ],
    [ "attributesCommands.h", "attributes_commands_8h.html", [
      [ "AttributeUndoableCommand", "class_ufe_1_1_attribute_undoable_command.html", "class_ufe_1_1_attribute_undoable_command" ]
    ] ],
    [ "attributesHandler.h", "attributes_handler_8h.html", [
      [ "AttributesHandler", "class_ufe_1_1_attributes_handler.html", "class_ufe_1_1_attributes_handler" ]
    ] ],
    [ "attributesNotification.h", "attributes_notification_8h.html", [
      [ "AttributeChanged", "class_ufe_1_1_attribute_changed.html", "class_ufe_1_1_attribute_changed" ],
      [ "AttributeValueChanged", "class_ufe_1_1_attribute_value_changed.html", "class_ufe_1_1_attribute_value_changed" ],
      [ "AttributeAdded", "class_ufe_1_1_attribute_added.html", "class_ufe_1_1_attribute_added" ],
      [ "AttributeRemoved", "class_ufe_1_1_attribute_removed.html", "class_ufe_1_1_attribute_removed" ],
      [ "AttributeConnectionChanged", "class_ufe_1_1_attribute_connection_changed.html", "class_ufe_1_1_attribute_connection_changed" ],
      [ "AttributeMetadataChanged", "class_ufe_1_1_attribute_metadata_changed.html", "class_ufe_1_1_attribute_metadata_changed" ]
    ] ],
    [ "attributesUndoableCommands.h", "attributes_undoable_commands_8h.html", "attributes_undoable_commands_8h" ],
    [ "baseUndoableCommands.h", "base_undoable_commands_8h.html", "base_undoable_commands_8h" ],
    [ "batchCompositeCommand.h", "batch_composite_command_8h.html", [
      [ "BatchCompositeCommand", "class_ufe_1_1_batch_composite_command.html", "class_ufe_1_1_batch_composite_command" ]
    ] ],
    [ "batchOpsHandler.h", "batch_ops_handler_8h.html", [
      [ "BatchOpsHandler", "class_ufe_1_1_batch_ops_handler.html", "class_ufe_1_1_batch_ops_handler" ]
    ] ],
    [ "camera.h", "camera_8h.html", [
      [ "Camera", "class_ufe_1_1_camera.html", "class_ufe_1_1_camera" ]
    ] ],
    [ "cameraHandler.h", "camera_handler_8h.html", [
      [ "CameraHandler", "class_ufe_1_1_camera_handler.html", "class_ufe_1_1_camera_handler" ]
    ] ],
    [ "cameraNotification.h", "camera_notification_8h.html", [
      [ "CameraChanged", "class_ufe_1_1_camera_changed.html", "class_ufe_1_1_camera_changed" ]
    ] ],
    [ "cameraUndoableCommands.h", "camera_undoable_commands_8h.html", "camera_undoable_commands_8h" ],
    [ "codeWrapper.h", "code_wrapper_8h.html", [
      [ "CodeWrapper", "class_ufe_1_1_code_wrapper.html", "class_ufe_1_1_code_wrapper" ],
      [ "CodeWrapperContainer", "class_ufe_1_1_code_wrapper_container.html", "class_ufe_1_1_code_wrapper_container" ]
    ] ],
    [ "codeWrapperContext.h", "code_wrapper_context_8h.html", [
      [ "CodeWrapperContext", "class_ufe_1_1_code_wrapper_context.html", "class_ufe_1_1_code_wrapper_context" ]
    ] ],
    [ "codeWrapperHandler.h", "code_wrapper_handler_8h.html", [
      [ "CodeWrapperHandler", "class_ufe_1_1_code_wrapper_handler.html", "class_ufe_1_1_code_wrapper_handler" ]
    ] ],
    [ "connection.h", "connection_8h.html", [
      [ "Connection", "class_ufe_1_1_connection.html", "class_ufe_1_1_connection" ]
    ] ],
    [ "connectionHandler.h", "connection_handler_8h.html", [
      [ "ConnectionHandler", "class_ufe_1_1_connection_handler.html", "class_ufe_1_1_connection_handler" ]
    ] ],
    [ "connections.h", "connections_8h.html", [
      [ "Connections", "class_ufe_1_1_connections.html", "class_ufe_1_1_connections" ]
    ] ],
    [ "contextOps.h", "context_ops_8h.html", [
      [ "ContextItem", "struct_ufe_1_1_context_item.html", "struct_ufe_1_1_context_item" ],
      [ "ContextOps", "class_ufe_1_1_context_ops.html", "class_ufe_1_1_context_ops" ]
    ] ],
    [ "contextOpsHandler.h", "context_ops_handler_8h.html", [
      [ "ContextOpsHandler", "class_ufe_1_1_context_ops_handler.html", "class_ufe_1_1_context_ops_handler" ]
    ] ],
    [ "debugTypesOstream.h", "debug_types_ostream_8h.html", "debug_types_ostream_8h" ],
    [ "globalSelection.h", "global_selection_8h.html", "global_selection_8h" ],
    [ "hierarchy.h", "hierarchy_8h.html", [
      [ "ChildFilterFlag", "struct_ufe_1_1_child_filter_flag.html", "struct_ufe_1_1_child_filter_flag" ],
      [ "Hierarchy", "class_ufe_1_1_hierarchy.html", "class_ufe_1_1_hierarchy" ]
    ] ],
    [ "hierarchyHandler.h", "hierarchy_handler_8h.html", [
      [ "HierarchyHandler", "class_ufe_1_1_hierarchy_handler.html", "class_ufe_1_1_hierarchy_handler" ]
    ] ],
    [ "light.h", "light_8h.html", [
      [ "Light", "class_ufe_1_1_light.html", "class_ufe_1_1_light" ],
      [ "SphereProps", "struct_ufe_1_1_light_1_1_sphere_props.html", "struct_ufe_1_1_light_1_1_sphere_props" ],
      [ "ConeProps", "struct_ufe_1_1_light_1_1_cone_props.html", "struct_ufe_1_1_light_1_1_cone_props" ],
      [ "DirectionalInterface", "class_ufe_1_1_light_1_1_directional_interface.html", "class_ufe_1_1_light_1_1_directional_interface" ],
      [ "SphereInterface", "class_ufe_1_1_light_1_1_sphere_interface.html", "class_ufe_1_1_light_1_1_sphere_interface" ],
      [ "ConeInterface", "class_ufe_1_1_light_1_1_cone_interface.html", "class_ufe_1_1_light_1_1_cone_interface" ],
      [ "AreaInterface", "class_ufe_1_1_light_1_1_area_interface.html", "class_ufe_1_1_light_1_1_area_interface" ]
    ] ],
    [ "lightHandler.h", "light_handler_8h.html", [
      [ "LightHandler", "class_ufe_1_1_light_handler.html", "class_ufe_1_1_light_handler" ]
    ] ],
    [ "lightNotification.h", "light_notification_8h.html", [
      [ "LightChanged", "class_ufe_1_1_light_changed.html", "class_ufe_1_1_light_changed" ]
    ] ],
    [ "log.h", "log_8h.html", "log_8h" ],
    [ "material.h", "material_8h.html", [
      [ "Material", "class_ufe_1_1_material.html", "class_ufe_1_1_material" ]
    ] ],
    [ "materialHandler.h", "material_handler_8h.html", [
      [ "MaterialHandler", "class_ufe_1_1_material_handler.html", "class_ufe_1_1_material_handler" ]
    ] ],
    [ "namedSelection.h", "named_selection_8h.html", "named_selection_8h" ],
    [ "nodeDef.h", "node_def_8h.html", "node_def_8h" ],
    [ "nodeDefHandler.h", "node_def_handler_8h.html", [
      [ "NodeDefHandler", "class_ufe_1_1_node_def_handler.html", "class_ufe_1_1_node_def_handler" ]
    ] ],
    [ "notification.h", "notification_8h.html", [
      [ "Notification", "class_ufe_1_1_notification.html", "class_ufe_1_1_notification" ]
    ] ],
    [ "object3d.h", "object3d_8h.html", [
      [ "Object3d", "class_ufe_1_1_object3d.html", "class_ufe_1_1_object3d" ]
    ] ],
    [ "object3dHandler.h", "object3d_handler_8h.html", [
      [ "Object3dHandler", "class_ufe_1_1_object3d_handler.html", "class_ufe_1_1_object3d_handler" ]
    ] ],
    [ "object3dNotification.h", "object3d_notification_8h.html", [
      [ "VisibilityChanged", "class_ufe_1_1_visibility_changed.html", "class_ufe_1_1_visibility_changed" ]
    ] ],
    [ "observableSelection.h", "observable_selection_8h.html", [
      [ "ObservableSelection", "class_ufe_1_1_observable_selection.html", "class_ufe_1_1_observable_selection" ]
    ] ],
    [ "observer.h", "observer_8h.html", [
      [ "Observer", "class_ufe_1_1_observer.html", "class_ufe_1_1_observer" ]
    ] ],
    [ "path.h", "path_8h.html", [
      [ "Path", "class_ufe_1_1_path.html", "class_ufe_1_1_path" ],
      [ "hash< Ufe_v4 ::Path >", "structstd_1_1hash_3_01_ufe__v4_01_1_1_path_01_4.html", "structstd_1_1hash_3_01_ufe__v4_01_1_1_path_01_4" ]
    ] ],
    [ "pathComponent.h", "path_component_8h.html", [
      [ "PathComponent", "class_ufe_1_1_path_component.html", "class_ufe_1_1_path_component" ],
      [ "hash< Ufe::PathComponent >", "structstd_1_1hash_3_01_ufe_1_1_path_component_01_4.html", "structstd_1_1hash_3_01_ufe_1_1_path_component_01_4" ]
    ] ],
    [ "pathMappingHandler.h", "path_mapping_handler_8h.html", [
      [ "PathMappingHandler", "class_ufe_1_1_path_mapping_handler.html", "class_ufe_1_1_path_mapping_handler" ]
    ] ],
    [ "pathSegment.h", "path_segment_8h.html", [
      [ "PathSegment", "class_ufe_1_1_path_segment.html", "class_ufe_1_1_path_segment" ]
    ] ],
    [ "pathString.h", "path_string_8h.html", "path_string_8h" ],
    [ "pathStringExcept.h", "path_string_except_8h.html", [
      [ "EmptyPathSegment", "class_ufe_1_1_empty_path_segment.html", "class_ufe_1_1_empty_path_segment" ],
      [ "InvalidPathComponentSeparator", "class_ufe_1_1_invalid_path_component_separator.html", "class_ufe_1_1_invalid_path_component_separator" ],
      [ "InvalidPath", "class_ufe_1_1_invalid_path.html", "class_ufe_1_1_invalid_path" ]
    ] ],
    [ "pathSubject.h", "path_subject_8h.html", [
      [ "PathSubject", "class_ufe_1_1_path_subject.html", "class_ufe_1_1_path_subject" ]
    ] ],
    [ "rtid.h", "rtid_8h.html", "rtid_8h" ],
    [ "runTimeMgr.h", "run_time_mgr_8h.html", [
      [ "RunTimeMgr", "class_ufe_1_1_run_time_mgr.html", "class_ufe_1_1_run_time_mgr" ],
      [ "Handlers", "struct_ufe_1_1_run_time_mgr_1_1_handlers.html", "struct_ufe_1_1_run_time_mgr_1_1_handlers" ]
    ] ],
    [ "scene.h", "scene_8h.html", [
      [ "Scene", "class_ufe_1_1_scene.html", "class_ufe_1_1_scene" ]
    ] ],
    [ "sceneItem.h", "scene_item_8h.html", [
      [ "SceneItem", "class_ufe_1_1_scene_item.html", "class_ufe_1_1_scene_item" ]
    ] ],
    [ "sceneItemList.h", "scene_item_list_8h.html", "scene_item_list_8h" ],
    [ "sceneItemOps.h", "scene_item_ops_8h.html", [
      [ "Duplicate", "struct_ufe_1_1_duplicate.html", "struct_ufe_1_1_duplicate" ],
      [ "Rename", "struct_ufe_1_1_rename.html", "struct_ufe_1_1_rename" ],
      [ "SceneItemOps", "class_ufe_1_1_scene_item_ops.html", "class_ufe_1_1_scene_item_ops" ]
    ] ],
    [ "sceneItemOpsHandler.h", "scene_item_ops_handler_8h.html", [
      [ "SceneItemOpsHandler", "class_ufe_1_1_scene_item_ops_handler.html", "class_ufe_1_1_scene_item_ops_handler" ]
    ] ],
    [ "sceneItemUtils.h", "scene_item_utils_8h.html", "scene_item_utils_8h" ],
    [ "sceneNotification.h", "scene_notification_8h.html", [
      [ "SceneChanged", "class_ufe_1_1_scene_changed.html", "class_ufe_1_1_scene_changed" ],
      [ "ObjectAdd", "class_ufe_1_1_object_add.html", "class_ufe_1_1_object_add" ],
      [ "ObjectDelete", "class_ufe_1_1_object_delete.html", "class_ufe_1_1_object_delete" ],
      [ "ObjectPostDelete", "class_ufe_1_1_object_post_delete.html", "class_ufe_1_1_object_post_delete" ],
      [ "ObjectPreDelete", "class_ufe_1_1_object_pre_delete.html", "class_ufe_1_1_object_pre_delete" ],
      [ "ObjectDestroyed", "class_ufe_1_1_object_destroyed.html", "class_ufe_1_1_object_destroyed" ],
      [ "ObjectPathChange", "class_ufe_1_1_object_path_change.html", "class_ufe_1_1_object_path_change" ],
      [ "ObjectRename", "class_ufe_1_1_object_rename.html", "class_ufe_1_1_object_rename" ],
      [ "ObjectReparent", "class_ufe_1_1_object_reparent.html", "class_ufe_1_1_object_reparent" ],
      [ "ObjectPathAdd", "class_ufe_1_1_object_path_add.html", "class_ufe_1_1_object_path_add" ],
      [ "ObjectPathRemove", "class_ufe_1_1_object_path_remove.html", "class_ufe_1_1_object_path_remove" ],
      [ "SubtreeInvalidate", "class_ufe_1_1_subtree_invalidate.html", "class_ufe_1_1_subtree_invalidate" ],
      [ "SceneCompositeNotification", "class_ufe_1_1_scene_composite_notification.html", "class_ufe_1_1_scene_composite_notification" ],
      [ "Op", "struct_ufe_1_1_scene_composite_notification_1_1_op.html", "struct_ufe_1_1_scene_composite_notification_1_1_op" ]
    ] ],
    [ "sceneSegmentHandler.h", "scene_segment_handler_8h.html", [
      [ "SceneSegmentHandler", "class_ufe_1_1_scene_segment_handler.html", "class_ufe_1_1_scene_segment_handler" ]
    ] ],
    [ "selection.h", "selection_8h.html", [
      [ "Selection", "class_ufe_1_1_selection.html", "class_ufe_1_1_selection" ]
    ] ],
    [ "selectionNotification.h", "selection_notification_8h.html", [
      [ "SelectionChanged", "class_ufe_1_1_selection_changed.html", "class_ufe_1_1_selection_changed" ],
      [ "SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html", "class_ufe_1_1_selection_item_appended" ],
      [ "SelectionItemRemoved", "class_ufe_1_1_selection_item_removed.html", "class_ufe_1_1_selection_item_removed" ],
      [ "SelectionItemInserted", "class_ufe_1_1_selection_item_inserted.html", "class_ufe_1_1_selection_item_inserted" ],
      [ "SelectionCleared", "class_ufe_1_1_selection_cleared.html", "class_ufe_1_1_selection_cleared" ],
      [ "SelectionReplaced", "class_ufe_1_1_selection_replaced.html", "class_ufe_1_1_selection_replaced" ],
      [ "SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html", "class_ufe_1_1_selection_composite_notification" ],
      [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html", "struct_ufe_1_1_selection_composite_notification_1_1_op" ]
    ] ],
    [ "selectionTrieFwd.h", "selection_trie_fwd_8h.html", "selection_trie_fwd_8h" ],
    [ "selectionUndoableCommands.h", "selection_undoable_commands_8h.html", [
      [ "SelectionAppendItem", "class_ufe_1_1_selection_append_item.html", "class_ufe_1_1_selection_append_item" ],
      [ "SelectionRemoveItem", "class_ufe_1_1_selection_remove_item.html", "class_ufe_1_1_selection_remove_item" ],
      [ "SelectionClear", "class_ufe_1_1_selection_clear.html", "class_ufe_1_1_selection_clear" ],
      [ "SelectionReplaceWith", "class_ufe_1_1_selection_replace_with.html", "class_ufe_1_1_selection_replace_with" ]
    ] ],
    [ "stringUtils.h", "string_utils_8h.html", "string_utils_8h" ],
    [ "subject.h", "subject_8h.html", [
      [ "Subject", "class_ufe_1_1_subject.html", "class_ufe_1_1_subject" ],
      [ "NotificationGuard", "class_ufe_1_1_notification_guard.html", "class_ufe_1_1_notification_guard" ]
    ] ],
    [ "transform3d.h", "transform3d_8h.html", [
      [ "EditTransform3dHint", "class_ufe_1_1_edit_transform3d_hint.html", "class_ufe_1_1_edit_transform3d_hint" ],
      [ "Transform3dRead", "class_ufe_1_1_transform3d_read.html", "class_ufe_1_1_transform3d_read" ],
      [ "Transform3d", "class_ufe_1_1_transform3d.html", "class_ufe_1_1_transform3d" ]
    ] ],
    [ "transform3dHandler.h", "transform3d_handler_8h.html", [
      [ "Transform3dHandler", "class_ufe_1_1_transform3d_handler.html", "class_ufe_1_1_transform3d_handler" ]
    ] ],
    [ "transform3dNotification.h", "transform3d_notification_8h.html", [
      [ "Transform3dChanged", "class_ufe_1_1_transform3d_changed.html", "class_ufe_1_1_transform3d_changed" ]
    ] ],
    [ "transform3dPathSubject.h", "transform3d_path_subject_8h.html", [
      [ "Transform3dPathSubject", "class_ufe_1_1_transform3d_path_subject.html", "class_ufe_1_1_transform3d_path_subject" ]
    ] ],
    [ "transform3dUndoableCommands.h", "transform3d_undoable_commands_8h.html", "transform3d_undoable_commands_8h" ],
    [ "trie.h", "trie_8h.html", [
      [ "Trie", "class_ufe_1_1_trie.html", "class_ufe_1_1_trie" ],
      [ "TrieNode", "class_ufe_1_1_trie_node.html", "class_ufe_1_1_trie_node" ],
      [ "Trie", "class_ufe_1_1_trie.html", "class_ufe_1_1_trie" ]
    ] ],
    [ "trie.imp.h", "trie_8imp_8h.html", null ],
    [ "types.h", "types_8h.html", "types_8h" ],
    [ "ufe.h", "ufe_8h.html", "ufe_8h" ],
    [ "ufeAssert.h", "ufe_assert_8h.html", "ufe_assert_8h" ],
    [ "ufeExcept.h", "ufe_except_8h.html", [
      [ "InvalidRunTimeName", "class_ufe_1_1_invalid_run_time_name.html", "class_ufe_1_1_invalid_run_time_name" ],
      [ "InvalidRunTimeId", "class_ufe_1_1_invalid_run_time_id.html", "class_ufe_1_1_invalid_run_time_id" ],
      [ "InvalidOperationOnPath", "class_ufe_1_1_invalid_operation_on_path.html", "class_ufe_1_1_invalid_operation_on_path" ],
      [ "InvalidOperationOnPathSegment", "class_ufe_1_1_invalid_operation_on_path_segment.html", "class_ufe_1_1_invalid_operation_on_path_segment" ],
      [ "InvalidValueGet", "class_ufe_1_1_invalid_value_get.html", "class_ufe_1_1_invalid_value_get" ]
    ] ],
    [ "uiInfoHandler.h", "ui_info_handler_8h.html", [
      [ "CellInfo", "struct_ufe_1_1_cell_info.html", "struct_ufe_1_1_cell_info" ],
      [ "UIInfoHandler", "class_ufe_1_1_u_i_info_handler.html", "class_ufe_1_1_u_i_info_handler" ],
      [ "Icon", "struct_ufe_1_1_u_i_info_handler_1_1_icon.html", "struct_ufe_1_1_u_i_info_handler_1_1_icon" ]
    ] ],
    [ "uiNodeGraphNode.h", "ui_node_graph_node_8h.html", [
      [ "UINodeGraphNode", "class_ufe_1_1_u_i_node_graph_node.html", "class_ufe_1_1_u_i_node_graph_node" ],
      [ "UINodeGraphNode_v4_1", "class_ufe_1_1_u_i_node_graph_node__v4__1.html", "class_ufe_1_1_u_i_node_graph_node__v4__1" ]
    ] ],
    [ "uiNodeGraphNodeHandler.h", "ui_node_graph_node_handler_8h.html", [
      [ "UINodeGraphNodeHandler", "class_ufe_1_1_u_i_node_graph_node_handler.html", "class_ufe_1_1_u_i_node_graph_node_handler" ]
    ] ],
    [ "undoableCommand.h", "undoable_command_8h.html", [
      [ "UndoableCommand", "class_ufe_1_1_undoable_command.html", "class_ufe_1_1_undoable_command" ],
      [ "CompositeUndoableCommand", "class_ufe_1_1_composite_undoable_command.html", "class_ufe_1_1_composite_undoable_command" ],
      [ "InsertChildCommand", "class_ufe_1_1_insert_child_command.html", "class_ufe_1_1_insert_child_command" ],
      [ "SceneItemResultUndoableCommand", "class_ufe_1_1_scene_item_result_undoable_command.html", "class_ufe_1_1_scene_item_result_undoable_command" ],
      [ "ConnectionResultUndoableCommand", "class_ufe_1_1_connection_result_undoable_command.html", "class_ufe_1_1_connection_result_undoable_command" ],
      [ "SelectionUndoableCommand", "class_ufe_1_1_selection_undoable_command.html", "class_ufe_1_1_selection_undoable_command" ]
    ] ],
    [ "undoableCommandMgr.h", "undoable_command_mgr_8h.html", [
      [ "UndoableCommandMgr", "class_ufe_1_1_undoable_command_mgr.html", "class_ufe_1_1_undoable_command_mgr" ],
      [ "UndoableCommandGuard", "class_ufe_1_1_undoable_command_guard.html", "class_ufe_1_1_undoable_command_guard" ]
    ] ],
    [ "value.h", "value_8h.html", "value_8h" ],
    [ "versionInfo.h", "version_info_8h.html", [
      [ "VersionInfo", "class_ufe_1_1_version_info.html", "class_ufe_1_1_version_info" ]
    ] ]
];