var dir_835eff7df150138af52bcde19e0af070 =
[
    [ "common", "dir_ee66e46240443c503419bd610d4b0573.html", "dir_ee66e46240443c503419bd610d4b0573" ],
    [ "globalSelection.h", "global_selection_8h.html", "global_selection_8h" ],
    [ "hierarchy.h", "hierarchy_8h.html", [
      [ "AppendedChild", "struct_ufe_1_1_appended_child.html", "struct_ufe_1_1_appended_child" ],
      [ "Hierarchy", "class_ufe_1_1_hierarchy.html", "class_ufe_1_1_hierarchy" ]
    ] ],
    [ "hierarchyHandler.h", "hierarchy_handler_8h.html", [
      [ "HierarchyHandler", "class_ufe_1_1_hierarchy_handler.html", "class_ufe_1_1_hierarchy_handler" ]
    ] ],
    [ "log.h", "log_8h.html", "log_8h" ],
    [ "notification.h", "notification_8h.html", [
      [ "Notification", "class_ufe_1_1_notification.html", "class_ufe_1_1_notification" ]
    ] ],
    [ "observableSelection.h", "observable_selection_8h.html", [
      [ "ObservableSelection", "class_ufe_1_1_observable_selection.html", "class_ufe_1_1_observable_selection" ]
    ] ],
    [ "observer.h", "observer_8h.html", [
      [ "Observer", "class_ufe_1_1_observer.html", "class_ufe_1_1_observer" ]
    ] ],
    [ "path.h", "path_8h.html", [
      [ "Path", "class_ufe_1_1_path.html", "class_ufe_1_1_path" ],
      [ "hash< Ufe_v1 ::Path >", "structstd_1_1hash_3_01_ufe__v1_01_1_1_path_01_4.html", "structstd_1_1hash_3_01_ufe__v1_01_1_1_path_01_4" ]
    ] ],
    [ "pathComponent.h", "path_component_8h.html", [
      [ "PathComponent", "class_ufe_1_1_path_component.html", "class_ufe_1_1_path_component" ],
      [ "hash< Ufe::PathComponent >", "structstd_1_1hash_3_01_ufe_1_1_path_component_01_4.html", "structstd_1_1hash_3_01_ufe_1_1_path_component_01_4" ]
    ] ],
    [ "pathSegment.h", "path_segment_8h.html", [
      [ "PathSegment", "class_ufe_1_1_path_segment.html", "class_ufe_1_1_path_segment" ]
    ] ],
    [ "rtid.h", "rtid_8h.html", "rtid_8h" ],
    [ "runTimeMgr.h", "run_time_mgr_8h.html", [
      [ "RunTimeMgr", "class_ufe_1_1_run_time_mgr.html", "class_ufe_1_1_run_time_mgr" ]
    ] ],
    [ "scene.h", "scene_8h.html", [
      [ "Scene", "class_ufe_1_1_scene.html", "class_ufe_1_1_scene" ]
    ] ],
    [ "sceneItem.h", "scene_item_8h.html", [
      [ "SceneItem", "class_ufe_1_1_scene_item.html", "class_ufe_1_1_scene_item" ]
    ] ],
    [ "sceneItemList.h", "scene_item_list_8h.html", "scene_item_list_8h" ],
    [ "sceneItemOps.h", "scene_item_ops_8h.html", [
      [ "Duplicate", "struct_ufe_1_1_duplicate.html", "struct_ufe_1_1_duplicate" ],
      [ "Rename", "struct_ufe_1_1_rename.html", "struct_ufe_1_1_rename" ],
      [ "SceneItemOps", "class_ufe_1_1_scene_item_ops.html", "class_ufe_1_1_scene_item_ops" ]
    ] ],
    [ "sceneItemOpsHandler.h", "scene_item_ops_handler_8h.html", [
      [ "SceneItemOpsHandler", "class_ufe_1_1_scene_item_ops_handler.html", "class_ufe_1_1_scene_item_ops_handler" ]
    ] ],
    [ "sceneNotification.h", "scene_notification_8h.html", [
      [ "ObjectAdd", "class_ufe_1_1_object_add.html", "class_ufe_1_1_object_add" ],
      [ "ObjectDelete", "class_ufe_1_1_object_delete.html", "class_ufe_1_1_object_delete" ],
      [ "ObjectPostDelete", "class_ufe_1_1_object_post_delete.html", "class_ufe_1_1_object_post_delete" ],
      [ "ObjectPreDelete", "class_ufe_1_1_object_pre_delete.html", "class_ufe_1_1_object_pre_delete" ],
      [ "ObjectPathChange", "class_ufe_1_1_object_path_change.html", "class_ufe_1_1_object_path_change" ],
      [ "ObjectRename", "class_ufe_1_1_object_rename.html", "class_ufe_1_1_object_rename" ],
      [ "ObjectReparent", "class_ufe_1_1_object_reparent.html", "class_ufe_1_1_object_reparent" ],
      [ "ObjectPathAdd", "class_ufe_1_1_object_path_add.html", "class_ufe_1_1_object_path_add" ],
      [ "ObjectPathRemove", "class_ufe_1_1_object_path_remove.html", "class_ufe_1_1_object_path_remove" ]
    ] ],
    [ "selection.h", "selection_8h.html", [
      [ "Selection", "class_ufe_1_1_selection.html", "class_ufe_1_1_selection" ]
    ] ],
    [ "selectionNotification.h", "selection_notification_8h.html", [
      [ "SelectionChanged", "class_ufe_1_1_selection_changed.html", "class_ufe_1_1_selection_changed" ],
      [ "SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html", "class_ufe_1_1_selection_item_appended" ],
      [ "SelectionItemRemoved", "class_ufe_1_1_selection_item_removed.html", "class_ufe_1_1_selection_item_removed" ],
      [ "SelectionCleared", "class_ufe_1_1_selection_cleared.html", "class_ufe_1_1_selection_cleared" ],
      [ "SelectionReplaced", "class_ufe_1_1_selection_replaced.html", "class_ufe_1_1_selection_replaced" ],
      [ "SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html", "class_ufe_1_1_selection_composite_notification" ],
      [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html", "struct_ufe_1_1_selection_composite_notification_1_1_op" ]
    ] ],
    [ "selectionUndoableCommands.h", "selection_undoable_commands_8h.html", [
      [ "SelectionAppendItem", "class_ufe_1_1_selection_append_item.html", "class_ufe_1_1_selection_append_item" ],
      [ "SelectionRemoveItem", "class_ufe_1_1_selection_remove_item.html", "class_ufe_1_1_selection_remove_item" ]
    ] ],
    [ "stringUtils.h", "string_utils_8h.html", "string_utils_8h" ],
    [ "subject.h", "subject_8h.html", [
      [ "Subject", "class_ufe_1_1_subject.html", "class_ufe_1_1_subject" ],
      [ "NotificationGuard", "class_ufe_1_1_notification_guard.html", "class_ufe_1_1_notification_guard" ]
    ] ],
    [ "transform3d.h", "transform3d_8h.html", [
      [ "Matrix4d", "struct_ufe_1_1_matrix4d.html", "struct_ufe_1_1_matrix4d" ],
      [ "Vector3d", "struct_ufe_1_1_vector3d.html", "struct_ufe_1_1_vector3d" ],
      [ "Transform3d", "class_ufe_1_1_transform3d.html", "class_ufe_1_1_transform3d" ]
    ] ],
    [ "transform3dHandler.h", "transform3d_handler_8h.html", [
      [ "Transform3dHandler", "class_ufe_1_1_transform3d_handler.html", "class_ufe_1_1_transform3d_handler" ]
    ] ],
    [ "transform3dNotification.h", "transform3d_notification_8h.html", [
      [ "Transform3dChanged", "class_ufe_1_1_transform3d_changed.html", "class_ufe_1_1_transform3d_changed" ]
    ] ],
    [ "transform3dUndoableCommands.h", "transform3d_undoable_commands_8h.html", [
      [ "BaseTransformUndoableCommand", "class_ufe_1_1_base_transform_undoable_command.html", "class_ufe_1_1_base_transform_undoable_command" ],
      [ "TranslateUndoableCommand", "class_ufe_1_1_translate_undoable_command.html", "class_ufe_1_1_translate_undoable_command" ],
      [ "RotateUndoableCommand", "class_ufe_1_1_rotate_undoable_command.html", "class_ufe_1_1_rotate_undoable_command" ],
      [ "ScaleUndoableCommand", "class_ufe_1_1_scale_undoable_command.html", "class_ufe_1_1_scale_undoable_command" ]
    ] ],
    [ "ufe.h", "ufe_8h.html", "ufe_8h" ],
    [ "undoableCommand.h", "undoable_command_8h.html", [
      [ "UndoableCommand", "class_ufe_1_1_undoable_command.html", "class_ufe_1_1_undoable_command" ],
      [ "CompositeUndoableCommand", "class_ufe_1_1_composite_undoable_command.html", "class_ufe_1_1_composite_undoable_command" ]
    ] ],
    [ "versionInfo.h", "version_info_8h.html", [
      [ "VersionInfo", "class_ufe_1_1_version_info.html", "class_ufe_1_1_version_info" ]
    ] ]
];