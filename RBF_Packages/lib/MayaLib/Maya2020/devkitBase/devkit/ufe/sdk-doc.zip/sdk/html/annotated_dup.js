var annotated_dup =
[
    [ "std", "namespacestd.html", "namespacestd" ],
    [ "Ufe", "namespace_ufe.html", "namespace_ufe" ]
];