var class_ufe_1_1_notification =
[
    [ "Notification", "class_ufe_1_1_notification.html#a39d4807b6e56cd5ff7c72eda0f4cc3c1", null ],
    [ "Notification", "class_ufe_1_1_notification.html#a61e6b6e3ee750f8b26f3b9fb531b74a2", null ],
    [ "~Notification", "class_ufe_1_1_notification.html#a527f8a0c7522efe7199c889a7de63615", null ],
    [ "staticCast", "class_ufe_1_1_notification.html#a3b906e291c557b1b21061418f65c525b", null ]
];