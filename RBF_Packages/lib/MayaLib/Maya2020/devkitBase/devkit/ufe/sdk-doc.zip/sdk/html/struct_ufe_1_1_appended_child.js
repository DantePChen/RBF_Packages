var struct_ufe_1_1_appended_child =
[
    [ "AppendedChild", "struct_ufe_1_1_appended_child.html#a73b38247eba91902eb4dcd9e4e23be64", null ],
    [ "child", "struct_ufe_1_1_appended_child.html#ac644ca91b13eb7ed8ba69c6a3ea6fb56", null ],
    [ "previousIndex", "struct_ufe_1_1_appended_child.html#a03c884b7057bf470717a10e6d1f923cb", null ],
    [ "previousPath", "struct_ufe_1_1_appended_child.html#a3b238469a1eb6431312c4d9b6e7fc189", null ]
];