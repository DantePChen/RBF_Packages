var searchData=
[
  ['notificationguard',['NotificationGuard',['../class_ufe_1_1_subject.html#ab1250cf1db50e39aaf7ba9d0a3e73163',1,'Ufe::Subject']]]
];
